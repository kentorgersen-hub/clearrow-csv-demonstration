# ClearRow: a reproducible CSV preparation example

This free evaluation sample shows how attendance records can be prepared while staff notes stay attached by an exact, stable record ID. All records and notes are fictional. An AI agent produced and checked the work with deterministic Python scripts; no human review, paid clients, customer savings or destination-system compatibility is claimed.

You may inspect, download and run this fictional demonstration for evaluation. It is a fixed-schema example, not a universal CSV cleaner. CSV cleaning and audit tools already exist, including [OpenRefine](https://openrefine.org/) and [CSV Handoff Kit](https://github.com/pbishay545/csv-handoff-kit); no unprecedented originality is claimed.

## Inspect the result

Download this repository as a ZIP, extract it, then open `outputs/clearrow-demo/report.html` locally. GitHub displays HTML source rather than the rendered report. The sample needs no account, API key or paid dependency.

| Run | Export rows | Eligible export rows | Held export rows |
| --- | ---: | ---: | ---: |
| First refresh | 11 | 4 | 7 |
| Second refresh | 6 | 6 | 0 |

All eight original note rows remain in state. Four note rows remain held for review after the second run; zero held export rows does not mean every note is resolved. Row order and a changed display name do not choose which note attaches.

Useful evidence:

- [Operating rules and limitations](outputs/clearrow-demo/README.txt)
- [First prepared CSV](outputs/clearrow-demo/run-1/import_ready.csv)
- [First exceptions](outputs/clearrow-demo/run-1/exceptions.csv)
- [Second prepared CSV](outputs/clearrow-demo/run-2/import_ready.csv)
- [Exact first-run evidence](outputs/clearrow-demo/run-1/evidence.json)
- [Recorded test results](outputs/clearrow-demo/tests.json)
- [SHA-256 manifest](outputs/clearrow-demo/manifest.json)

**Raw CSV warning:** original files deliberately include formula-like test text. Inspect them as plain text; do not open raw originals by double-clicking in a spreadsheet. CSV has no cell types. Import identifier columns as Text to preserve leading zeros. Review-output escaping is a specific prefix rule, not a universal spreadsheet-safety guarantee.

## Run the checks

Use Python 3.10 or later. Run from the extracted repository folder:

```text
python -m unittest discover -s src -p test_clearrow.py -v
```

The existing suite has 20 tests. It checks fixed-schema behavior, including ambiguous dates, duplicates, changed IDs, exact note retention, row reconciliation and reproducible substantive outputs. Passing these tests does not prove acceptance by your CRM or spreadsheet program.

To reproduce the two data preparations into a new `reproduction` folder:

```text
python src/clearrow.py --export outputs/clearrow-demo/run-1/original_export.csv --notes outputs/clearrow-demo/run-1/original_notes.csv --out reproduction/run-1 --label "First refresh" --synthetic-demo
python src/clearrow.py --export outputs/clearrow-demo/run-2/original_export.csv --notes reproduction/run-1/notes_state.json --out reproduction/run-2 --label "Second refresh" --synthetic-demo
```

On Windows, `py` may replace `python`. Existing output directories are refused. The commands write only to the named fresh output folders, use the standard library and make no network requests. Input basenames in the evidence differ from the original demonstration build; compare data, decisions and counts rather than expecting every report byte to match. Keep original files unchanged and inspect exceptions before using any prepared output.

The source engine's technical ceiling is 100,000 rows per input. That does not expand the paid pilot intake below.

## A separately scoped commission

[ClearRow's current commission and booking terms](https://kentorgersen.gumroad.com/l/clearrow-csv-preparation) offer one agreed file outcome, at most two CSV inputs and 1,000 total rows, for US$160 base split US$80 upfront and US$80 on completion, plus applicable tax/card conversion. We agree the schema, rules and three acceptance examples before booking. The files, exceptions, written recipe and checks are delivered through Gumroad, with a review copy within two UK business days after prerequisites and one included correction for missed agreed requirements requested within 30 days after final delivery.

This public example is not a customer order or evidence of willingness to pay. For an inquiry, use the contact on the offer page and share only fictional or appropriately anonymised examples. The AI-enabled handling environment must be agreed before any real files are supplied. Personal/confidential records, live account access, remote installation, financial/payroll/tax work and ongoing support are outside this pilot.
