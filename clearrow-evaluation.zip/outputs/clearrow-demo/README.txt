CLEARROW SYNTHETIC DEMONSTRATION

Open report.html for the two-run overview. All people, notes and records are fictional.

Purpose
Prepare one recurring attendance export while matching notes by stable attendance record ID. This is a file-preparation demonstration, not a tested integration with a named system.

Input contract
Export CSV: record_id,member_id,member_name,session_date,attendance_status
Notes CSV: record_id,staff_note
IDs are case-sensitive text containing letters, digits, underscores or hyphens. Leading zeros are preserved in the files. Each attendance record must have a unique record_id. A member can have several attendance records, each with its own record_id. Dates must already be valid YYYY-MM-DD. Status must be booked, present, absent or cancelled after trimming/lowercasing. Input CSVs must be UTF-8. Exact header sets are required; extra columns cause rejection rather than silent loss.

Rules
Surrounding whitespace is trimmed from export fields and note IDs. Staff-note text is retained exactly. Every row with a duplicated export ID is held, even if identical. Duplicated note IDs hold the matching export row. No fuzzy matching, deduplication guess, missing-value invention or date interpretation is performed. A note without a current export record is retained. Successful runs retain ID-to-member bindings; reassignment of a known record ID to another member is held on subsequent runs.

Recurring operation
Use the previous run's notes_state.json with the next export, or supply a corrected notes CSV. JSON state retains all notes and known record/member bindings. Editing the review CSV is not supported as an input round-trip because its protective prefixes change values. An operator must resolve held source records. The engine does not remove unresolved records from state or choose between conflicting notes. Correcting notes through CSV starts a new binding state; retain the prior JSON if continuity checks are required.

Outputs in each run
original_export.csv and original_notes.csv/JSON: unchanged source copies
cleaned.csv: eligible canonical records with attached notes
import_ready.csv: eligible records mapped to the demo target schema
exceptions.csv: held source rows and reasons for operator review
changes.csv: normalizations and exact-ID note attachments
provenance.csv: output row to export row and note row references
staff_notes_review.csv: every note for review, including unresolved records
notes_state.json: exact note text and known record/member bindings for recurrence
evidence.json: exact values, dispositions, counts, rule definitions and file SHA-256 hashes
report.html: human-readable run summary

CSV safety and identifiers
Raw original copies deliberately include formula-like sample text. Do not open these raw CSVs by double-clicking in a spreadsheet application. All CSV fields are quoted. Formula-like prefixes (= + - @ after leading whitespace, or an initial tab/line break) are conservatively held from import output. Review CSVs prefix such values with an apostrophe. Exact originals remain in JSON evidence. This is a specific prefix-handling rule, not a universal security certification. CSV has no cell types; opening it in Excel or another spreadsheet may coerce IDs and drop leading zeros. Import ID columns as text. No actual external import has been tested.

Limits
The paid pilot intake is capped at 1,000 rows total across supplied files. The software technical ceiling below does not expand the paid pilot scope.

Engine technical ceiling: one supplied export and one notes source per run, 10 MB and 100,000 rows per input, 100,000 characters per cell. No macros, live database changes, CRM login, external enrichment or automatic conflict resolution. Existing output directories are refused. Data remains local to the preparation engine; the surrounding chat/tool service has its own data handling. No confidentiality certification is claimed.

Verification
tests.json records the automated synthetic tests. manifest.json records hashes of delivered files except the manifest itself. Zero customer orders, payments, savings or sales are represented by this demonstration.
